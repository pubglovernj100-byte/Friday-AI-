package com.friday.assistant

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var log: LinearLayout
    private lateinit var input: EditText
    private val navy = Color.rgb(5, 11, 24)
    private val blue = Color.rgb(45, 160, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(navy); setPadding(20,24,20,16) }
        val title = TextView(this).apply { text = "F R I D A Y"; textSize = 26f; setTextColor(blue); gravity = Gravity.CENTER; setPadding(0,8,0,6) }
        val subtitle = TextView(this).apply { text = "PERSONAL AI ASSISTANT • ONLINE READY"; textSize = 11f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER }
        root.addView(title)
        root.addView(subtitle)
        val orb = TextView(this).apply { text = "◉"; textSize = 70f; setTextColor(blue); gravity = Gravity.CENTER; setPadding(0,20,0,16) }
        root.addView(orb)
        log = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(log) }
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        addMessage("FRIDAY", "Hello! Main FRIDAY hoon. Abhi ye starter version hai. Voice aur AI API connect karne ke liye project ready kiya ja raha hai.")
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply { hint = "FRIDAY se baat karo..."; setHintTextColor(0xFF8E9AAF.toInt()); setTextColor(Color.WHITE); setSingleLine(true); setBackgroundColor(0xFF101B2D.toInt()); setPadding(14,10,14,10) }
        row.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val send = Button(this).apply { text = "SEND"; setTextColor(blue) }
        row.addView(send)
        root.addView(row)
        send.setOnClickListener { sendText() }
        setContentView(root)
    }
    private fun sendText() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        addMessage("YOU", text)
        input.setText("")
        addMessage("FRIDAY", "Message receive ho gaya! Is starter app mein live AI reply ke liye API connection abhi configure nahi hai.")
    }
    private fun addMessage(who: String, body: String) {
        val tv = TextView(this).apply {
            text = "$who\n$body"
            textSize = 15f
            setTextColor(if (who == "YOU") Color.WHITE else 0xFFB8DFFF.toInt())
            setPadding(12,12,12,12)
            setBackgroundColor(0xFF101B2D.toInt())
        }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0,8,0,8)
        log.addView(tv, lp)
    }
}
