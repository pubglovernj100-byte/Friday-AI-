FRIDAY Android Starter Project

This is a genuine starter source project (not an APK). It contains a simple futuristic Android chat UI.

Current features:
- Android app shell named FRIDAY
- Dark blue UI with orb-style header
- Basic text entry and placeholder response

Not yet included:
- Connected AI/API backend
- Voice recognition / speech output
- Persistent memory
- Wake word/background listening
- APK build/signing

To build, open this folder in Android Studio, sync Gradle, then Build > Build APK(s).
Android Studio and Android SDK are required for compiling an APK.
